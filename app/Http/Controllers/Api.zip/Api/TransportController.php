<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{ Vehicle, Driver, Student, TimetableSlot, ClassRoom, };
use Illuminate\Http\{JsonResponse, Request};
use Illuminate\Support\Facades\DB;

// ============================================================
// TransportController
// ============================================================

class TransportController extends Controller
{
    public function index(): JsonResponse
    {
        $routes = \App\Models\TransportRoute::with(['vehicle', 'driver', 'students'])
            ->withCount('students')
            ->get();

        return response()->json(['success' => true, 'data' => $routes]);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name'       => 'required|string|max:255',
            'vehicle_id' => 'required|exists:vehicles,id',
           'driver_id'  => 'required|exists:drivers,id',
            'stops'      => 'required|array|min:1',
            'stops.*.name'         => 'required|string',
            'stops.*.pickup_time'  => 'required|date_format:H:i',
            'stops.*.drop_time'    => 'required|date_format:H:i',
            'monthly_fee'          => 'required|numeric|min:0',
        ]);

        $route = \App\Models\TransportRoute::create($request->validated());

        return response()->json(['success' => true, 'data' => $route], 201);
    }
   

    public function live(): JsonResponse
    {
        // Returns live GPS data for all active vehicles today
        $live = \App\Models\Vehicle::with(['currentRoute', 'driver'])
            ->where('status', 'active')
            ->get()
            ->map(fn($v) => [
                'vehicle_id'  => $v->id,
                'number'      => $v->registration_number,
                'route'       => $v->currentRoute?->name,
                'driver'      => $v->driver?->name,
                'lat'         => $v->last_lat,
                'lng'         => $v->last_lng,
                'speed'       => $v->last_speed,
                'updated_at'  => $v->location_updated_at?->diffForHumans(),
            ]);

        return response()->json(['success' => true, 'data' => $live]);
    }

    public function assignStudent(Request $request, \App\Models\TransportRoute $transportRoute): JsonResponse
    {
        $request->validate(['student_id' => 'required|exists:students,id', 'stop' => 'required|string']);

        $transportRoute->students()->syncWithoutDetaching([
            $request->student_id => ['stop' => $request->stop],
        ]);

        return response()->json(['success' => true, 'message' => 'Student assigned to route.']);
    }

    public function update(Request $request, \App\Models\TransportRoute $transportRoute): JsonResponse
    {
        $transportRoute->update($request->validated());
        return response()->json(['success' => true, 'data' => $transportRoute->fresh()]);
    }

    public function destroy(\App\Models\TransportRoute $transportRoute): JsonResponse
    {
        $transportRoute->delete();
        return response()->json(['success' => true, 'message' => 'Route deleted.']);
    }

    public function show(\App\Models\TransportRoute $transportRoute): JsonResponse
    {
        return response()->json(['success' => true, 'data' => $transportRoute->load(['vehicle', 'driver', 'students.classRoom'])]);
    }
}