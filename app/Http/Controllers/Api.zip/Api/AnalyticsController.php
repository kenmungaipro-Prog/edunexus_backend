<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{TimetableSlot, ClassRoom, Subject, Teacher, Exam, Grade, Book, BookIssue, Route, Event, Message, User};
use Illuminate\Http\{JsonResponse, Request};
use Illuminate\Support\Facades\DB;


// ============================================================
// AnalyticsController
// ============================================================

class AnalyticsController extends Controller
{
    public function overview(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => [
                'avg_attendance'  => 94.6,
                'pass_rate'       => 87.2,
                'fee_collection'  => 68.4,
                'teacher_rating'  => 4.7,
            ],
        ]);
    }

    public function gradePerformance(): JsonResponse
    {
        $data = ClassRoom::withCount('students')
            ->with(['grades' => fn($q) => $q->selectRaw('class_id, AVG(percentage) as avg_score')->groupBy('class_id')])
            ->get()
            ->map(fn($c) => [
                'class'    => $c->name,
                'students' => $c->students_count,
                'avg'      => round($c->grades->avg('avg_score') ?? 0, 1),
            ]);

        return response()->json(['success' => true, 'data' => $data]);
    }

    public function attendanceTrend(): JsonResponse
    {
        $trend = collect(range(1, 12))->map(fn($m) => [
            'month' => now()->month($m)->format('M'),
            'rate'  => round(rand(88, 98) + (rand(0, 9) / 10), 1),
        ]);

        return response()->json(['success' => true, 'data' => $trend]);
    }

    public function feeAnalytics(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => [
                'by_type'   => \App\Models\FeeType::withSum(['fees as collected' => fn($q) => $q->where('status', 'paid')], 'amount')->get(),
                'by_month'  => collect(range(1, 12))->map(fn($m) => [
                    'month'     => now()->month($m)->format('M'),
                    'collected' => \App\Models\Fee::whereMonth('paid_at', $m)->where('status', 'paid')->sum('amount'),
                ]),
            ],
        ]);
    }

    public function examPerformance(): JsonResponse
{
    // 1. Overall Exam Status Stats
    $stats = [
        'total'     => Exam::count(),
        'upcoming'  => Exam::where('status', 'scheduled')->count(),
        'ongoing'   => Exam::where('status', 'ongoing')->count(),
        'completed' => Exam::where('status', 'completed')->count(),
    ];

    // 2. Grade Distribution (e.g., How many A+, A, B...)
    // This maps exactly to your "Grade distribution" sidebar chart
    $grades = Grade::select('letter_grade as grade', DB::raw('count(*) as count'))
        ->groupBy('letter_grade')
        ->orderBy('letter_grade')
        ->get()
        ->map(function ($item) {
            $total = Grade::count() ?: 1;
            return [
                'grade' => $item->grade,
                'count' => (int)$item->count,
                'pct'   => round(($item->count / $total) * 100),
                // Assigning colors based on grade
                'color' => match($item->grade) {
                    'A+' => 'bg-emerald-400',
                    'A'  => 'bg-blue-400',
                    'B'  => 'bg-amber-400',
                    'C'  => 'bg-orange-400',
                    default => 'bg-red-400',
                }
            ];
        });

    // 3. Subject Performance (Avg score and Pass rate)
    // This maps to your "Subject performance" bottom chart
    $subjects = DB::table('grades')
        ->join('exams', 'grades.exam_id', '=', 'exams.id')
        ->join('subjects', 'exams.subject_id', '=', 'subjects.id')
        ->select(
            'subjects.name',
            DB::raw('ROUND(AVG(grades.percentage), 1) as avg'),
            DB::raw('ROUND(SUM(CASE WHEN grades.status = "pass" THEN 1 ELSE 0 END) / COUNT(*) * 100, 1) as pass')
        )
        ->groupBy('subjects.name')
        ->get();

    return response()->json([
        'success' => true,
        'data' => [
            'stats'    => $stats,
            'grades'   => $grades,
            'subjects' => $subjects
        ]
    ]);
}
}