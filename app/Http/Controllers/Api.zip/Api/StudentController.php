<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StudentRequest;
use App\Models\Student;
use App\Models\User;
use App\Models\AcademicSession;
use App\Imports\StudentsImport;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Facades\Excel;

class StudentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $students = Student::with(['classRoom', 'parent'])
            ->where('school_id', currentSchoolId())
            ->when($request->class_id, fn ($q, $v) => $q->where('class_id', $v))
            ->when($request->status,   fn ($q, $v) => $q->where('status', $v))
            ->when($request->gender,   fn ($q, $v) => $q->where('gender', $v))
            ->when($request->search,   fn ($q, $v) => $q->where(function ($q) use ($v) {
                $q->where('first_name',  'like', "%{$v}%")
                  ->orWhere('last_name',   'like', "%{$v}%")
                  ->orWhere('admission_no','like', "%{$v}%")
                  ->orWhere('roll_number', 'like', "%{$v}%");
            }))
            ->orderBy($request->sort_by  ?? 'first_name', $request->sort_dir ?? 'asc')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $students]);
    }

    public function store(StudentRequest $request): JsonResponse
    {
        $student = DB::transaction(function () use ($request) {

            // Create parent user if no existing parent_id
            $parentId = $request->parent_id;
            if (! $parentId && $request->parent_email) {
                $parent = User::firstOrCreate(
                    ['email' => $request->parent_email],
                    [
                        'name'      => $request->parent_name,
                        'password'  => Hash::make('Parent@123'),
                        'role'      => 'parent',
                        'status'    => 'active',
                        'school_id' => currentSchoolId(),
                    ]
                );
                $parentId = $parent->id;
            }

            $student = Student::create([
                ...$request->validated(),
                'school_id'    => currentSchoolId(),
                'session_id'   => $request->session_id ?? currentSession(),
                'parent_id'    => $parentId,
                'admission_no' => $this->generateAdmissionNo(),
                'roll_number'  => $this->generateRollNumber($request->class_id),
            ]);

            if ($request->hasFile('profile_photo')) {
                $path = $request->file('profile_photo')
                    ->store("students/photos/{$student->id}", 'public');
                $student->update(['profile_photo' => $path]);
            }

            return $student;
        });

        return response()->json([
            'success' => true,
            'message' => 'Student created successfully.',
            'data'    => $student->load('classRoom', 'parent'),
        ], 201);
    }

    public function show(Student $student): JsonResponse
    {
        $this->authorizeSchool($student);

        return response()->json([
            'success' => true,
            'data'    => $student->load([
                'classRoom',
                'parent',
                'attendance',
                'fees.feeType',
                'grades.exam.subject',
            ]),
        ]);
    }

    public function update(StudentRequest $request, Student $student): JsonResponse
    {
        $this->authorizeSchool($student);

        $student->update($request->validated());

        if ($request->hasFile('profile_photo')) {
            $path = $request->file('profile_photo')
                ->store("students/photos/{$student->id}", 'public');
            $student->update(['profile_photo' => $path]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Student updated.',
            'data'    => $student->fresh('classRoom'),
        ]);
    }

    public function destroy(Student $student): JsonResponse
    {
        $this->authorizeSchool($student);
        $student->delete();

        return response()->json(['success' => true, 'message' => 'Student removed.']);
    }

    public function import(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,csv,xls|max:5120',
        ]);

        $import = new StudentsImport(currentSchoolId(), currentSession());
        Excel::import($import, $request->file('file'));

        return response()->json([
            'success'  => true,
            'message'  => "Imported {$import->getRowCount()} students successfully.",
            'failures' => $import->failures(),
        ]);
    }

    public function reportCard(Student $student): JsonResponse
    {
        $this->authorizeSchool($student);

        $grades = $student->grades()
            ->with('exam.subject')
            ->whereHas('exam', fn ($q) => $q->where('session_id', currentSession()))
            ->get()
            ->groupBy('exam.subject.name');

        $rank = Student::where('class_id', $student->class_id)
            ->get()
            ->sortByDesc(fn ($s) => $s->grades()->avg('percentage'))
            ->values()
            ->search(fn ($s) => $s->id === $student->id);

        return response()->json([
            'success' => true,
            'data'    => [
                'student'            => $student->load('classRoom'),
                'grades'             => $grades,
                'attendance_percentage' => $student->attendance_percentage,
                'rank'               => ($rank !== false) ? $rank + 1 : null,
                'total_students'     => Student::where('class_id', $student->class_id)->count(),
            ],
        ]);
    }

    public function attendanceHistory(Student $student, Request $request): JsonResponse
    {
        $this->authorizeSchool($student);

        $history = $student->attendance()
            ->when($request->month, fn ($q, $v) => $q->whereMonth('date', $v))
            ->when($request->year,  fn ($q, $v) => $q->whereYear('date',  $v))
            ->orderByDesc('date')
            ->get();

        return response()->json([
            'success' => true,
            'data'    => [
                'records'    => $history,
                'percentage' => $student->attendance_percentage,
                'summary'    => [
                    'present' => $history->where('status', 'present')->count(),
                    'absent'  => $history->where('status', 'absent')->count(),
                    'late'    => $history->where('status', 'late')->count(),
                    'holiday' => $history->where('status', 'holiday')->count(),
                ],
            ],
        ]);
    }

    public function feeHistory(Student $student): JsonResponse
    {
        $this->authorizeSchool($student);

        $fees = $student->fees()
            ->with('feeType', 'collectedBy')
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'success' => true,
            'data'    => [
                'fees'         => $fees,
                'total_paid'   => $fees->where('status', 'paid')->sum('amount'),
                'total_pending'=> $fees->where('status', 'pending')->sum('amount'),
                'total_overdue'=> $fees->where('status', 'overdue')->sum('amount'),
            ],
        ]);
    }

    private function generateAdmissionNo(): string
    {
        $year  = now()->format('Y');
        $count = Student::where('school_id', currentSchoolId())
                        ->whereYear('created_at', $year)
                        ->count() + 1;
        return "ADM-{$year}-" . str_pad($count, 4, '0', STR_PAD_LEFT);
    }

    private function generateRollNumber(int $classId): string
    {
        $count = Student::where('class_id', $classId)->count() + 1;
        return 'S-' . str_pad($count + 1000, 4, '0', STR_PAD_LEFT);
    }

    private function authorizeSchool(Student $student): void
    {
        if ($student->school_id !== currentSchoolId()) {
            abort(403, 'Access denied.');
        }
    }
}
