<?php

namespace App\Http\Controllers\Api\Finance;

use App\Http\Controllers\Controller;
use App\Models\FinanceStatuses;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Student;
use App\Services\Finance\StudentBalanceService;
use Illuminate\Http\JsonResponse;

class StudentFinanceController extends Controller
{
    public function __construct(private readonly StudentBalanceService $balances) {}

    public function summary(Student $student): JsonResponse
    {
        $this->authorizeSchool($student);

        $balance = $this->balances->recalculate($student);
        $overdue = Invoice::where('school_id', currentSchoolId())
            ->where('student_id', $student->id)
            ->where('status', FinanceStatuses::INVOICE_OVERDUE)
            ->sum('balance');

        $dueSoon = Invoice::where('school_id', currentSchoolId())
            ->where('student_id', $student->id)
            ->whereIn('status', [FinanceStatuses::INVOICE_ISSUED, FinanceStatuses::INVOICE_PARTIALLY_PAID])
            ->whereBetween('due_date', [today(), today()->addDays(7)])
            ->sum('balance');

        return response()->json(['success' => true, 'data' => [
            'student' => $student->load('classRoom'),
            'balance' => $balance,
            'overdue_balance' => (float) $overdue,
            'due_soon_balance' => (float) $dueSoon,
        ]]);
    }

    public function statement(Student $student): JsonResponse
    {
        $this->authorizeSchool($student);

        $invoices = Invoice::with('items.feeCategory')
            ->where('school_id', currentSchoolId())
            ->where('student_id', $student->id)
            ->orderByDesc('created_at')
            ->get();

        $payments = Payment::with(['receipt', 'allocations.invoice'])
            ->where('school_id', currentSchoolId())
            ->where('student_id', $student->id)
            ->orderByDesc('payment_date')
            ->get();

        $balance = $this->balances->recalculate($student);
        $overdue = Invoice::where('school_id', currentSchoolId())
            ->where('student_id', $student->id)
            ->where('status', FinanceStatuses::INVOICE_OVERDUE)
            ->sum('balance');

        $dueSoon = Invoice::where('school_id', currentSchoolId())
            ->where('student_id', $student->id)
            ->whereIn('status', [FinanceStatuses::INVOICE_ISSUED, FinanceStatuses::INVOICE_PARTIALLY_PAID])
            ->whereBetween('due_date', [today(), today()->addDays(7)])
            ->sum('balance');

        return response()->json([
            'success' => true,
            'data' => [
                'student' => $student->load('classRoom'),
                'balance' => $balance,
                'overdue_balance' => (float) $overdue,
                'due_soon_balance' => (float) $dueSoon,
                'invoices' => $invoices,
                'payments' => $payments,
            ],
        ]);
    }

    private function authorizeSchool(Student $student): void
    {
        abort_if($student->school_id !== currentSchoolId(), 404);
    }
}
