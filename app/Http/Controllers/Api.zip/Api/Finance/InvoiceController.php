<?php

namespace App\Http\Controllers\Api\Finance;

use App\Http\Controllers\Controller;
use App\Models\FeeStructure;
use App\Models\FinanceStatuses;
use App\Models\Invoice;
use App\Models\Student;
use App\Services\AuditService;
use App\Services\Finance\InvoiceGenerationService;
use App\Services\Finance\StudentBalanceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function __construct(
        private readonly InvoiceGenerationService $invoices,
        private readonly StudentBalanceService $balances,
        private readonly AuditService $audit,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $invoices = Invoice::with(['student.classRoom', 'items.feeCategory'])
            ->where('school_id', currentSchoolId())
            ->when($request->student_id, fn ($query, $value) => $query->where('student_id', $value))
            ->when($request->status, fn ($query, $value) => $query->where('status', $value))
            ->when($request->class_id, fn ($query, $value) => $query->where('class_id', $value))
            ->orderByDesc('created_at')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $invoices]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'student_id' => 'required|exists:students,id',
            'due_date' => 'nullable|date',
            'currency' => 'nullable|string|size:3',
            'status' => 'nullable|in:draft,issued',
            'items' => 'required|array|min:1',
            'items.*.fee_category_id' => 'nullable|exists:fee_categories,id',
            'items.*.description' => 'required|string|max:255',
            'items.*.quantity' => 'nullable|numeric|min:0.01',
            'items.*.unit_price' => 'required|numeric|min:0',
            'items.*.discount_amount' => 'nullable|numeric|min:0',
        ]);

        $student = Student::where('school_id', currentSchoolId())->findOrFail($data['student_id']);

        $invoice = DB::transaction(function () use ($data, $student) {
            $items = $data['items'];
            $subtotal = collect($items)->sum(fn ($item) => ((float) ($item['quantity'] ?? 1) * (float) $item['unit_price']) - (float) ($item['discount_amount'] ?? 0));
            $status = $data['status'] ?? FinanceStatuses::INVOICE_ISSUED;

            $invoice = Invoice::create([
                'school_id' => currentSchoolId(),
                'student_id' => $student->id,
                'session_id' => currentSession(),
                'class_id' => $student->class_id,
                'invoice_number' => $this->invoices->nextInvoiceNumber(currentSchoolId()),
                'issue_date' => $status === FinanceStatuses::INVOICE_ISSUED ? now()->toDateString() : null,
                'due_date' => $data['due_date'] ?? null,
                'currency' => strtoupper($data['currency'] ?? 'KES'),
                'subtotal' => $subtotal,
                'total' => $subtotal,
                'balance' => $subtotal,
                'status' => $status,
                'created_by' => auth()->id(),
            ]);

            foreach ($items as $item) {
                $quantity = (float) ($item['quantity'] ?? 1);
                $discount = (float) ($item['discount_amount'] ?? 0);
                $total = max(0, ($quantity * (float) $item['unit_price']) - $discount);

                $invoice->items()->create([
                    'fee_category_id' => $item['fee_category_id'] ?? null,
                    'description' => $item['description'],
                    'quantity' => $quantity,
                    'unit_price' => $item['unit_price'],
                    'discount_amount' => $discount,
                    'total' => $total,
                ]);
            }

            $this->balances->recalculate($student, $invoice->currency);

            return $invoice;
        });

        $this->audit->log($invoice, 'invoice.created', null, $invoice->toArray());

        return response()->json(['success' => true, 'data' => $invoice->load('items.feeCategory', 'student.classRoom')], 201);
    }

    public function show(Invoice $invoice): JsonResponse
    {
        $this->authorizeSchool($invoice);

        return response()->json(['success' => true, 'data' => $invoice->load('student.classRoom', 'items.feeCategory', 'allocations.payment')]);
    }

    public function issue(Invoice $invoice): JsonResponse
    {
        $this->authorizeSchool($invoice);

        $oldValues = $invoice->toArray();

        $invoice->update([
            'status' => FinanceStatuses::INVOICE_ISSUED,
            'issue_date' => $invoice->issue_date ?: now()->toDateString(),
        ]);

        $this->balances->recalculate($invoice->student, $invoice->currency);
        $this->audit->log($invoice, 'invoice.issued', $oldValues, $invoice->fresh()->toArray());

        return response()->json(['success' => true, 'data' => $invoice->fresh()]);
    }

    public function cancel(Invoice $invoice): JsonResponse
    {
        $this->authorizeSchool($invoice);

        abort_if((float) $invoice->amount_paid > 0, 422, 'Paid invoices cannot be cancelled.');

        $oldValues = $invoice->toArray();

        $invoice->update(['status' => FinanceStatuses::INVOICE_CANCELLED]);
        $this->balances->recalculate($invoice->student, $invoice->currency);
        $this->audit->log($invoice, 'invoice.cancelled', $oldValues, $invoice->fresh()->toArray());

        return response()->json(['success' => true, 'message' => 'Invoice cancelled.']);
    }

    public function generate(Request $request): JsonResponse
    {
        $data = $request->validate([
            'fee_structure_id' => 'required|exists:fee_structures,id',
            'student_id' => 'nullable|exists:students,id',
            'due_date' => 'nullable|date',
        ]);

        $structure = FeeStructure::where('school_id', currentSchoolId())->findOrFail($data['fee_structure_id']);

        if (! empty($data['student_id'])) {
            $student = Student::where('school_id', currentSchoolId())->findOrFail($data['student_id']);
            $invoice = $this->invoices->createFromFeeStructure($student, $structure, $data['due_date'] ?? null);
            $this->audit->log($invoice, 'invoice.generated', null, $invoice->toArray());

            return response()->json(['success' => true, 'data' => $invoice], 201);
        }

        $created = $this->invoices->bulkCreateForClass($structure, $data['due_date'] ?? null);

        $created->each(fn (Invoice $invoice) => $this->audit->log($invoice, 'invoice.generated', null, $invoice->toArray()));

        return response()->json(['success' => true, 'data' => ['created' => $created->count(), 'invoices' => $created]], 201);
    }

    private function authorizeSchool(Invoice $invoice): void
    {
        abort_if($invoice->school_id !== currentSchoolId(), 404);
    }
}
