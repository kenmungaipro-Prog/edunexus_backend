<?php

namespace App\Http\Controllers\Api\Finance;

use App\Http\Controllers\Controller;
use App\Http\Requests\FeeRequest;
use App\Models\FinanceStatuses;
use App\Models\Payment;
use App\Models\Student;
use App\Services\AuditService;
use App\Services\Finance\PaymentAllocationService;
use App\Services\Finance\ReceiptService;
use App\Services\Finance\StudentBalanceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public function __construct(
        private readonly PaymentAllocationService $allocations,
        private readonly ReceiptService $receipts,
        private readonly StudentBalanceService $balances,
        private readonly AuditService $audit,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $payments = Payment::with(['student.classRoom', 'receipt', 'allocations.invoice'])
            ->where('school_id', currentSchoolId())
            ->when($request->student_id, fn ($query, $value) => $query->where('student_id', $value))
            ->when($request->status, fn ($query, $value) => $query->where('status', $value))
            ->when($request->method, fn ($query, $value) => $query->where('payment_method', $value))
            ->orderByDesc('payment_date')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $payments]);
    }

    public function store(Request $request): JsonResponse
    {
        return $this->collect($request);
    }

    public function collect(Request $request): JsonResponse
    {
        $data = $request->validate([
            'student_id' => 'required|exists:students,id',
            'amount' => 'required|numeric|min:0.01',
            'payment_method' => 'required|in:' . implode(',', FeeRequest::PAYMENT_METHODS),
            'payment_channel' => 'nullable|string|max:40',
            'currency' => 'nullable|string|size:3',
            'reference_number' => 'nullable|string|max:100',
            'external_transaction_id' => 'nullable|string|max:100',
            'payer_name' => 'nullable|string|max:255',
            'payer_phone' => 'nullable|string|max:40',
            'auto_allocate' => 'sometimes|boolean',
        ]);

        $requiresReference = in_array($data['payment_method'], ['mpesa', 'bank_transfer', 'bank_deposit', 'card', 'online'], true);
        abort_if($requiresReference && blank($data['reference_number'] ?? null) && blank($data['external_transaction_id'] ?? null), 422, 'Transaction reference is required for this payment method.');

        $student = Student::where('school_id', currentSchoolId())->findOrFail($data['student_id']);

        $payment = DB::transaction(function () use ($data, $student) {
            $payment = Payment::create([
                'school_id' => currentSchoolId(),
                'student_id' => $student->id,
                'payment_number' => $this->nextPaymentNumber(currentSchoolId()),
                'payment_method' => $data['payment_method'],
                'payment_channel' => $data['payment_channel'] ?? $data['payment_method'],
                'currency' => strtoupper($data['currency'] ?? 'KES'),
                'amount' => $data['amount'],
                'payment_date' => now(),
                'reference_number' => $data['reference_number'] ?? null,
                'external_transaction_id' => $data['external_transaction_id'] ?? null,
                'payer_name' => $data['payer_name'] ?? null,
                'payer_phone' => $data['payer_phone'] ?? null,
                'status' => FinanceStatuses::PAYMENT_SUCCESSFUL,
                'received_by' => auth()->id(),
            ]);

            $this->receipts->issue($payment);

            return $payment;
        });

        $this->audit->log($payment, 'payment.collected', null, $payment->toArray());

        if ($request->boolean('auto_allocate', true)) {
            $this->allocations->allocateOldest($payment->fresh('student'));
        } else {
            $this->balances->recalculate($student, $payment->currency);
        }

        return response()->json([
            'success' => true,
            'message' => 'Payment recorded.',
            'data' => $payment->fresh(['student.classRoom', 'receipt', 'allocations.invoice']),
        ], 201);
    }

    public function show(Payment $payment): JsonResponse
    {
        $this->authorizeSchool($payment);

        return response()->json(['success' => true, 'data' => $payment->load('student.classRoom', 'receipt', 'allocations.invoice')]);
    }

    public function allocate(Payment $payment): JsonResponse
    {
        $this->authorizeSchool($payment);
        $oldValues = $payment->toArray();
        $allocated = $this->allocations->allocateOldest($payment->load('student'));
        $payment = $payment->fresh();

        $this->audit->log($payment, 'payment.allocated', $oldValues, $payment->toArray());

        return response()->json(['success' => true, 'message' => "Allocated {$allocated}.", 'data' => $payment->load(['allocations.invoice', 'receipt'])]);
    }

    public function allocationResults(Payment $payment): JsonResponse
    {
        $this->authorizeSchool($payment);

        $payment->load(['allocations.invoice', 'receipt']);
        $allocated = $payment->allocations->sum('amount_allocated');
        $remaining = max(0, (float) $payment->amount - $allocated);

        return response()->json([
            'success' => true,
            'data' => [
                'payment' => $payment,
                'allocated_amount' => (float) $allocated,
                'remaining_amount' => (float) $remaining,
                'allocations' => $payment->allocations->map(fn ($allocation) => [
                    'id' => $allocation->id,
                    'invoice_id' => $allocation->invoice_id,
                    'amount_allocated' => (float) $allocation->amount_allocated,
                    'invoice_number' => $allocation->invoice?->invoice_number,
                    'invoice_balance' => $allocation->invoice?->balance,
                    'invoice_status' => $allocation->invoice?->status,
                ]),
            ],
        ]);
    }

    public function reverse(Request $request, Payment $payment): JsonResponse
    {
        $this->authorizeSchool($payment);

        $data = $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        abort_if(in_array($payment->status, [FinanceStatuses::PAYMENT_REVERSED, FinanceStatuses::PAYMENT_REFUNDED], true), 422, 'Payment is already reversed or refunded.');

        $oldValues = $payment->toArray();

        DB::transaction(function () use ($payment, $data) {
            foreach ($payment->allocations()->with('invoice')->get() as $allocation) {
                $invoice = $allocation->invoice;
                $paid = max(0, (float) $invoice->amount_paid - (float) $allocation->amount_allocated);

                $invoice->update([
                    'amount_paid' => $paid,
                    'balance' => max(0, (float) $invoice->total - $paid),
                    'status' => $paid <= 0 ? FinanceStatuses::INVOICE_ISSUED : FinanceStatuses::INVOICE_PARTIALLY_PAID,
                ]);

                $allocation->delete();
            }

            $payment->update([
                'status' => FinanceStatuses::PAYMENT_REVERSED,
                'reference_number' => trim(($payment->reference_number ? $payment->reference_number . ' | ' : '') . 'Reversal: ' . $data['reason']),
            ]);

            $payment->receipt?->update(['status' => FinanceStatuses::RECEIPT_REVERSED]);
        });

        $payment = $payment->fresh();
        $this->balances->recalculate($payment->student, $payment->currency);
        $this->audit->log($payment, 'payment.reversed', $oldValues, $payment->toArray());

        return response()->json(['success' => true, 'message' => 'Payment reversed.', 'data' => $payment->fresh(['receipt', 'allocations'])]);
    }

    public function receipt(Payment $payment): JsonResponse
    {
        $this->authorizeSchool($payment);

        $receipt = $payment->receipt ?: $this->receipts->issue($payment);

        return response()->json(['success' => true, 'data' => $receipt->load('payment.student.classRoom')]);
    }

    private function authorizeSchool(Payment $payment): void
    {
        abort_if($payment->school_id !== currentSchoolId(), 404);
    }

    private function nextPaymentNumber(int $schoolId): string
    {
        do {
            $number = 'PAY-' . $schoolId . '-' . now()->format('YmdHis') . '-' . random_int(100, 999);
        } while (Payment::where('school_id', $schoolId)->where('payment_number', $number)->exists());

        return $number;
    }
}
