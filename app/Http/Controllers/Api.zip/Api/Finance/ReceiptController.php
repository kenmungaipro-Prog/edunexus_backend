<?php

namespace App\Http\Controllers\Api\Finance;

use App\Http\Controllers\Controller;
use App\Models\Receipt;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReceiptController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $receipts = Receipt::with(['payment.student.classRoom', 'issuedBy'])
            ->where('school_id', currentSchoolId())
            ->when($request->status, fn ($query, $status) => $query->where('status', $status))
            ->orderByDesc('created_at')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $receipts]);
    }

    public function show(Receipt $receipt): JsonResponse
    {
        if ($receipt->school_id !== currentSchoolId()) {
            abort(404);
        }

        return response()->json([
            'success' => true,
            'data' => $receipt->load('payment.student.classRoom', 'issuedBy'),
        ]);
    }
}