<?php

namespace App\Services\Finance;

use App\Models\Student;
use App\Models\FeeStructure;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\FinanceStatuses;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class InvoiceGenerationService
{
    /**
     * Generate an invoice for a specific student from a fee structure.
     */
    public function createFromFeeStructure(Student $student, FeeStructure $structure, ?string $dueDate = null): Invoice
    {
        return DB::transaction(function () use ($student, $structure, $dueDate) {
            // Safeguard against duplicate generation if business rules dictate
            $invoiceNumber = $this->generateInvoiceNumber($structure->school_id);

            // 1. Initialize parent invoice container
            $invoice = Invoice::create([
                'school_id'        => $structure->school_id,
                'student_id'       => $student->id,
                'session_id'       => $structure->session_id,
                'class_id'         => $structure->class_id ?? $student->class_id,
                'invoice_number'   => $invoiceNumber,
                'issue_date'       => now()->toDateString(),
                'due_date'         => $dueDate ?? now()->addDays(30)->toDateString(),
                'currency'         => strtoupper($structure->currency ?? 'KES'),
                'subtotal'         => 0.00,
                'discount_total'   => 0.00,
                'waiver_total'     => 0.00,
                'penalty_total'    => 0.00,
                'total'            => 0.00,
                'amount_paid'      => 0.00,
                'balance'          => 0.00,
                'status'           => FinanceStatuses::INVOICE_ISSUED,
                'posted_to_ledger' => false,
                'created_by'       => auth()->id(),
            ]);

            $runningSubtotal = 0.00;

            // 2. Iterate and append individual fee structure components
            foreach ($structure->feeStructureItems as $item) {
                InvoiceItem::create([
                    'invoice_id'         => $invoice->id,
                    'fee_category_id'    => $item->fee_category_id,
                    'description'        => $item->description ?? $item->feeCategory->name,
                    'quantity'           => 1.00,
                    'unit_price'         => $item->amount,
                    'discount_amount'    => 0.00,
                    'total'              => $item->amount,
                    'revenue_account_id' => $item->revenue_account_id ?? $item->feeCategory->revenue_account_id,
                ]);

                $runningSubtotal += $item->amount;
            }

            // 3. Finalize invoice financial totals
            $invoice->update([
                'subtotal' => $runningSubtotal,
                'total'    => $runningSubtotal,
                'balance'  => $runningSubtotal,
            ]);

            // 4. Update the student balance summary record
            app(StudentBalanceService::class)->recalculate($student, $invoice->currency);

            return $invoice->load('items.feeCategory');
        });
    }

    /**
     * Batch generate invoices for an entire class level linked to a structure.
     */
    public function bulkCreateForClass(FeeStructure $structure, ?string $dueDate = null): Collection
    {
        // Fetch all active students assigned to this classroom track
        $students = Student::where('school_id', $structure->school_id)
            ->where('class_id', $structure->class_id)
            ->get();

        $generatedInvoices = collect();

        foreach ($students as $student) {
            // Safeguard against double billing for the same session/structure track
            $exists = Invoice::where('student_id', $student->id)
                ->where('session_id', $structure->session_id)
                ->whereNotIn('status', [FinanceStatuses::INVOICE_CANCELLED])
                ->exists();

            if (!$exists) {
                $generatedInvoices->push($this->createFromFeeStructure($student, $structure, $dueDate));
            }
        }

        return $generatedInvoices;
    }

    /**
     * Internal sequencer to format structured clean invoice reference keys.
     */
    private function generateInvoiceNumber(int $schoolId): string
    {
        do {
            $number = 'INV-' . $schoolId . '-' . now()->format('Ymd') . '-' . Str::upper(Str::random(4));
        } while (Invoice::where('school_id', $schoolId)->where('invoice_number', $number)->exists());

        return $number;
    }
}