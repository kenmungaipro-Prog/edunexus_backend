<?php

namespace App\Services\Finance;

use App\Models\Student;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\FinanceStatuses;
use App\Models\StudentFinanceBalance;
use Illuminate\Support\Facades\DB;

class StudentBalanceService
{
    /**
     * Recalculate and update the absolute balance state for a student.
     * Guaranteed to use atomicity via database state compilation.
     *
     * @param Student $student
     * @param string $currency
     * @return StudentFinanceBalance
     */
    public function recalculate(Student $student, string $currency = 'KES'): StudentFinanceBalance
    {
        return DB::transaction(function () use ($student, $currency) {
            // 1. Calculate total active billing (exclude drafts, credit notes, and cancellations)
            $totalInvoiced = Invoice::where('student_id', $student->id)
                ->where('currency', $currency)
                ->whereNotIn('status', FinanceStatuses::invoiceExcludedFromBalance())
                ->sum('total');

            // 2. Calculate total payments successfully collected from the student
            $totalPaid = Payment::where('student_id', $student->id)
                ->where('status', '!=', FinanceStatuses::PAYMENT_FAILED)
                ->where('status', '!=', FinanceStatuses::PAYMENT_REVERSED)
                ->sum('amount');

            // 3. Compute net outstanding balance
            $netBalance = $totalInvoiced - $totalPaid;

            // 4. Atomically persist or update the single source of truth ledger record
            return StudentFinanceBalance::updateOrCreate(
                [
                    'school_id'  => $student->school_id ?? currentSchoolId(),
                    'student_id' => $student->id,
                    'currency'   => strtoupper($currency),
                ],
                [
                    'total_invoiced' => $totalInvoiced,
                    'total_paid'     => $totalPaid,
                    'balance'        => $netBalance,
                    'updated_at'     => now(),
                ]
            );
        });
    }
}