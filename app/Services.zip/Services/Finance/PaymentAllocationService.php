<?php

namespace App\Services\Finance;

use App\Models\Payment;
use App\Models\Invoice;
use App\Models\PaymentAllocation;
use App\Models\FinanceStatuses;
use Illuminate\Support\Facades\DB;

class PaymentAllocationService
{
    /**
     * Atomically match a payment across outstanding open liabilities using FIFO order.
     *
     * @param Payment $payment
     * @return void
     */
    public function allocate(Payment $payment): void
    {
        DB::transaction(function () use ($payment) {
            // Guard clause to ensure we only process successful cash inflows
            if (in_array($payment->status, [FinanceStatuses::PAYMENT_FAILED, FinanceStatuses::PAYMENT_REVERSED])) {
                return;
            }

            // 1. Pull chronological open balances for the targeted student
            $openInvoices = Invoice::where('student_id', $payment->student_id)
                ->whereIn('status', FinanceStatuses::invoicePayableStatuses())
                ->orderBy('issue_date', 'asc')
                ->orderBy('id', 'asc')
                ->get();

            $unallocatedFunds = (float) $payment->amount;

            foreach ($openInvoices as $invoice) {
                if ($unallocatedFunds <= 0) {
                    break;
                }

                $invoiceRemainingLiability = (float) $invoice->balance;

                if ($invoiceRemainingLiability <= 0) {
                    continue;
                }

                // Determine exact fraction match to absorb
                $allocationAmount = min($unallocatedFunds, $invoiceRemainingLiability);

                // 2. Generate transaction allocation junction trace
                PaymentAllocation::create([
                    'payment_id'   => $payment->id,
                    'invoice_id'   => $invoice->id,
                    'amount'       => $allocationAmount,
                    'allocated_at' => now(),
                ]);

                // 3. Increment absolute values on invoice record
                $newAmountPaid = (float) $invoice->amount_paid + $allocationAmount;
                $newBalance = (float) $invoice->balance - $allocationAmount;
                
                $invoice->amount_paid = $newAmountPaid;
                $invoice->balance = $newBalance;

                // Adjust payment states dynamically based on completion
                if ($invoice->balance <= 0) {
                    $invoice->status = FinanceStatuses::INVOICE_PAID;
                } else {
                    $invoice->status = FinanceStatuses::INVOICE_PARTIALLY_PAID;
                }

                $invoice->save();

                $unallocatedFunds -= $allocationAmount;
            }

            // 4. Update parent collection visibility attributes
            if ($unallocatedFunds <= 0) {
                $payment->status = FinanceStatuses::PAYMENT_FULLY_ALLOCATED;
            } else {
                $payment->status = FinanceStatuses::PAYMENT_PARTIALLY_ALLOCATED;
            }
            
            $payment->save();
        });
    }
}